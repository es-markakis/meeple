import { NgModule } from '@angular/core';

import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
    MatButtonModule, MatCheckboxModule, MatCardModule, MatInputModule,
    MatRadioModule, MatSelectModule, MatIconModule, MatSlideToggleModule,
    MatGridListModule, MatDialogModule, MatDialog, MatProgressSpinnerModule,
    MatSnackBarModule, MatButtonToggleModule, MatMenuModule, MatChipsModule
} from '@angular/material';

import { MatTabsModule } from '@angular/material/tabs';


import { BrowserAnimationsModule } from '@angular/platform-browser/animations';





@NgModule({
    imports: [
        ReactiveFormsModule,
        FormsModule,
        MatSelectModule,
        MatInputModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatSlideToggleModule,
        MatCardModule,
        MatProgressSpinnerModule,
        MatSnackBarModule,
        MatMenuModule,
        MatIconModule,
        MatTabsModule,
        FlexLayoutModule,
        MatChipsModule
    ],
    declarations: [
    ],
    providers: [MatDialog],
    exports: [
        MatButtonModule,
        MatCheckboxModule,
        MatCardModule,
        MatInputModule,
        BrowserAnimationsModule,
        MatRadioModule,
        MatSelectModule,
        MatIconModule,
        MatSlideToggleModule,
        MatGridListModule,
        MatDialogModule,
        MatProgressSpinnerModule,
        MatSnackBarModule,
        MatTabsModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule,
        MatMenuModule,
        MatChipsModule
    ],
    entryComponents: [
    ]
})
export class SharedModule { }
