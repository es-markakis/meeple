import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { User } from '../model/user';

@Component({
  selector: 'app-administrator',
  templateUrl: './administrator.component.html',
  styleUrls: ['./administrator.component.scss']
})
export class AdministratorComponent implements OnInit {

  constructor(public services: Service) {

  }

  user: User;

  ngOnInit() {

    this.getUsers();

  }

  getUsers() {
    this.services.get('http://localhost:8090/users')
      .subscribe((data) => this.user = data[0]);
  }

}
